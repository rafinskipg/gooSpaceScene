require('ember-runtime/~tests/suites/enumerable');

Ember.MutableEnumerableTests = Ember.EnumerableTests.extend();

require('ember-runtime/~tests/suites/mutable_enumerable/addObject');
require('ember-runtime/~tests/suites/mutable_enumerable/removeObject');
