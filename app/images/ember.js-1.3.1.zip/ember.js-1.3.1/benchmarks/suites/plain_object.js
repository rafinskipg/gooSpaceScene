/*global bench alert*/

bench("Ember.Object.create()", function() {
  Ember.Object.create();
});

